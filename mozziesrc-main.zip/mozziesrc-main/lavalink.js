async function song(client, message, args) = {
    
}