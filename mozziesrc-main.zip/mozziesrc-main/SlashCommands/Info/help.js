const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const config = require("../../botconfig/config.json");
const ee = require("../../botconfig/embed.json");
const emoji = require("../../botconfig/emojis.json");
module.exports = {
  name: "help",
  category: "Info",
  description: "Commands Of Mozzie",
  runslash: async (client, interaction, guildData, player, prefix) => {
    try {
   const mainmenu = new MessageEmbed()
.setAuthor(`Mozzie Help Panel`, client.user.displayAvatarURL({dynamic: true}), config.links.opmusicinv)
 .addField(`General [5]`, `\`247\`, \`autoplay\`, \`prefix\`, \`reset\`, \`requester\``)
 .addField(`Music [20]`, `\`clear\`, \`join\`, \`disconnect\`, \`loop\`, \`nowplaying\`, \`replay\`, \`pause\`, \`play\`, \`queue\`, \`remove\`, \`seek\`, \`grab\`, \`resume\`, \`search\`, \`previous\`, \`shuffle\`, \`skip\`, \`skipto\`, \`stop\`, \`volume\``) 
 .addField(`Filters [8]`, `\`8d\`, \`darthvader\`, \`karaoke\`, \`nightcore\`, \`pitch\`, \`slowmotion\`, \`speed\`, \`tremolo\``)
 .addField(`Utilities [6]`, `\`help\`, \`invite\`, \`ping\`, \`bot-info\`, \`vote\`, \`support\``)
.setTimestamp() 
  .setFooter(ee.footertext, ee.footericon)

.setColor(ee.wrongcolor)

      interaction.reply({embeds: [mainmenu]});

    } catch (e) {
      console.log(String(e.stack).bgRed)
      const emesdf = new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setAuthor(`An Error Occurred`)
        .setDescription(`\`\`\`${e.message}\`\`\``);
      return interaction.reply({ embeds: [emesdf] });
    }
  }
}; 
