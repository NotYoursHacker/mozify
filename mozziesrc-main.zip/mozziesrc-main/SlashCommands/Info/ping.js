const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const config = require("../../botconfig/config.json");
const ee = require("../../botconfig/embed.json");
const emoji = require("../../botconfig/emojis.json");
module.exports = {
  name: "ping",
  category: "Info",
  description: "Ping Of Mozzie",
  runslash: async (client, interaction, guildData, player, prefix) => {
    try {
    const mainmenu = new MessageEmbed()
                        .setColor(ee.color)

      .setDescription(`\`\`\`yml\nHeart beat rate: ${client.ws.ping}ms\`\`\``);


interaction.reply({embeds: [mainmenu]})
    } catch (e) {
      console.log(String(e.stack).bgRed)
      const emesdf = new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setAuthor(`An Error Occurred`)
        .setDescription(`\`\`\`${e.message}\`\`\``);
      return interaction.reply({ embeds: [emesdf] });
    }
  }
}; 
