const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const config = require("../../botconfig/config.json");
const ee = require("../../botconfig/embed.json");
const emoji = require("../../botconfig/emojis.json");
module.exports = {
  name: "invite",
  category: "Info",
  description: "Invite Of Mozzie",
  runslash: async (client, interaction, guildData, player, prefix) => {
    try {
const mainmenu = new MessageEmbed()
.setTitle("Invite Links For Mozzie!") 
 .addField('Mozzie', `[Invite Me](https://discord.com/api/oauth2/authorize?client_id=948803590951153695&permissions=8&scope=bot)`, true) 
.addField('Vote Me', `[Click here](https://top.gg/bot/948803590951153695/vote)`, true) 
.addField('Support Server', `[Click here](https://discord.gg/yE5Azypyhe)`)
.setColor(interaction.guild.me.displayHexColor !== '#000000' ? interaction.guild.me.displayHexColor : "#ff0000") 
      interaction.reply({embeds: [mainmenu]});
    } catch (e) {
      console.log(String(e.stack).bgRed)
      const emesdf = new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setAuthor(`An Error Occurred`)
        .setDescription(`\`\`\`${e.message}\`\`\``);
      return interaction.reply({ embeds: [emesdf] });
    }
  }
}; 
