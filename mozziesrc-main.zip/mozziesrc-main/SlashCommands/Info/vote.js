const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const config = require("../../botconfig/config.json");
const ee = require("../../botconfig/embed.json");
const emoji = require("../../botconfig/emojis.json");
module.exports = {
  name: "vote",
  category: "Info",
  description: "Vote Of Mozzie",
  runslash: async (client, interaction, guildData, player, prefix) => {
    try {
const button = new MessageActionRow()
.addComponents(
 new MessageButton()
.setLabel("Vote Me!")
  .setStyle("LINK")
  .setURL("https://top.gg/bot/948803590951153695/vote")
  );

      const mainmenu = new MessageEmbed()
.setDescription("Click [here](https://top.gg/bot/948803590951153695/vote) to vote me on top.gg!")
     
      .setColor(ee.color)

interaction.reply({embeds: [mainmenu], components: [button]})
    } catch (e) {
      console.log(String(e.stack).bgRed)
      const emesdf = new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setAuthor(`An Error Occurred`)
        .setDescription(`\`\`\`${e.message}\`\`\``);
      return interaction.reply({ embeds: [emesdf] });
    }
  }
}; 
