module.exports = async (client, message, guild, cmd, shard) => {

const moment = require('moment');
const { mem, cpu, os } = require('node-os-utils');
const { stripIndent } = require('common-tags');
const bytes = require('bytes');
const prettyMilliseconds = require("pretty-ms")
const Discord  = require("discord.js");
const config = require("../../botconfig/config.json");
const ee = require("../../botconfig/embed.json");
const emoji = require(`../../botconfig/emojis.json`);


  


      let connectedchannelsamount = 0;
      let guilds = client.guilds.cache.map((guild) => guild);
      for (let i = 0; i < guilds.length; i++) {
        if (guilds[i].me.voice.channel) connectedchannelsamount += 1;
      }
      if (connectedchannelsamount > client.guilds.cache.size) connectedchannelsamount = client.guilds.cache.size;

      let users = 0;
      client.guilds.cache.forEach(guild => {
        users += guild.memberCount;
      })
      
        
        const memusage = process.memoryUsage();
        
      const clmao = stripIndent`
↳ Version    :: v2.1.0
↳ Shard      :: ${parseInt(client.shard.ids) + 1}/${client.shard.count}
↳ Clusters   :: ${parseInt(client.shard.ids) + 1}
↳ Servers    :: ${client.guilds.cache.size.toLocaleString()}
↳ Users      :: ${users.toLocaleString()}
↳ Players    :: ${connectedchannelsamount}
    `;
    const slmao = stripIndent`
↳ Node.js    :: v16.6.13
↳ Memory     :: ${Math.round(memusage.heapUsed / 1024 / 1024)}/${Math.round(memusage.heapTotal / 1024 / 1024)}mb
↳ Platform   :: ${await os.oos()}
↳ CPU        :: ${cpu.model()}
  `;

  const all = client.manager.nodes.map(node => 
      `
Node Id   ::  ${(node.options.identifier)}
State     ::  Connected
`
        ).join('\n\n- - - - - - - - - - - - - -\n');

      
      
    const { MessageEmbed } = require("discord.js")

    let lmao = new MessageEmbed()

.setColor("#RED")
.setFooter("This Will Be Reloaded Every 1 Hour", ee.footericon)
.setThumbnail(ee.footericon)
.addField(`GENERAL:`, `\`\`\`asciidoc\n${clmao}\n\`\`\``)
.addField(`STATISTICS:`, `\`\`\`asciidoc\n${slmao}\n\`\`\``)
.addField("NODE STATS", `\`\`\`asciidoc\n${all}\n\`\`\``)
      

    
      console.log("\n")
      console.log(`[CLIENT] => [READY] ${client.user.tag} IS READY...`.bold.bgWhite.brightMagenta)


      const stats = "954364918914760725";
      const statsChannel = client.channels.cache.get(stats)

      statsChannel.bulkDelete(2);
        statsChannel.send({embeds: [lmao]}).then((msg) => {
            setInterval(() => {
                let relmao = new MessageEmbed()

.setColor("#fd6260")
.setFooter("This Will Be Reloaded Every 1 Hour", ee.footericon)
.setThumbnail(ee.footericon)
.addField(`GENERAL:`, `\`\`\`asciidoc\n${clmao}\n\`\`\``)
.addField(`STATISTICS:`, `\`\`\`asciidoc\n${slmao}\n\`\`\``)
.addField("NODE STATS", `\`\`\`asciidoc\n${all}\n\`\`\``)

msg.edit(({embeds: [relmao]}))

 console.log(`[CLIENT] => [STATS] STATS SENT...`.bold.bgWhite.brightMagenta)


                }, 1000000);
        })



      

      

}

  
