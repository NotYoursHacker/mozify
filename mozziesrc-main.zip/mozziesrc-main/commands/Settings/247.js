const { 
  MessageEmbed,
  MessageActionRow,
  MessageButton
} = require(`discord.js`);
const { autojoin } = require("../../handlers/autojoin");
const config = require(`../../botconfig/config.json`);
const ee = require(`../../botconfig/embed.json`);
const Topgg = require('@top-gg/sdk');
const emoji = require(`../../botconfig/emojis.json`);

module.exports = {
    name: `24/7`,
    aliases: [`247`, `autojoin`],
    premium: true,
    perms: [ `SEND_MESSAGES` ],
    botperms: [ `SEND_MESSAGES`, `EMBED_LINK` ],
    category: `Settings`,
    description: `247 Of Mozzie`,
    usage: `24/7`,
    premium: true,
    memberpermissions: [`ADMINISTRATOR`],
    run: async (client, message, args, guildData, player, prefix) => {

        const memchannel = message.member.voice.channel;
            if(!memchannel) {
                const eme = new MessageEmbed()
                .setColor(message.guild.me.displayHexColor !== '#000000' ? message.guild.me.displayHexColor : "#ff0000")       
               .setDescription(`${emoji.msg.ERROR} | You have to be connected to a voice channel before you can use this command.`)
                return message.channel.send({embeds: [eme]})
            }

            guildData.ajenabled = !guildData.ajenabled
            guildData.textChannel = guildData.ajenabled ? null : message.channel.id;
            guildData.voiceChannel = guildData.ajenabled ? null : memchannel.id;
            guildData.save()

            
await autojoin(message.guild.id, message.member.voice.channel.id, message.channel.id)

             
            const suc = new MessageEmbed()
            .setDescription(`${guildData.ajenabled ? emoji.msg.SUCCESS : emoji.msg.ERROR} | 24/7 Mode is now **${guildData.ajenabled ? `Enabled` : `Disabled`}** Successfully`)
            .setColor(message.guild.me.displayHexColor !== '#000000' ? message.guild.me.displayHexColor : "#ff0000") 
        

          
            message.channel.send({embeds: [suc]})
      
        }
}; 
