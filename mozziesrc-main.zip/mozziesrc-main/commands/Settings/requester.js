const {
  MessageEmbed
} = require("discord.js");
const config = require("../../botconfig/config.json");
const ee = require("../../botconfig/embed.json");
const emoji = require(`../../botconfig/emojis.json`);
module.exports = {
  name: "requester",
  category: "Settings",
  aliases: ["requester", "request"],
  cooldown: 5,
  usage: "requester",
  description: "Requester Of Mozzie",
  run: async (client, message, args, guildData, player, prefix) => {
    try {
      const emee = new MessageEmbed()
.setColor(message.guild.me.displayHexColor !== '#000000' ? message.guild.me.displayHexColor : "#ff0000") 

     .setDescription("**Requester** will be shown on each track.")


      message.channel.send({embeds: [emee]});
    } catch (e) {
      console.log(String(e.stack).bgRed)
const emesdf = new MessageEmbed()
 .setColor(message.guild.me.displayHexColor !== '#000000' ? message.guild.me.displayHexColor : "#ff0000") 

.setAuthor(`An Error Occurred`)
.setDescription(`\`\`\`${e.message}\`\`\``);
return message.channel.send({embeds: [emesdf]});
    }
  }
}
