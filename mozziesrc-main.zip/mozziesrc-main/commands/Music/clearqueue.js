const {
  MessageEmbed
} = require(`discord.js`);
const config = require(`../../botconfig/config.json`);
const ee = require(`../../botconfig/embed.json`);
const emoji = require(`../../botconfig/emojis.json`);
module.exports = {
  name: `clear`,
  category: `Music`,
  aliases: [`clear`],
  description: `Cleares the Queue`,
  usage: `clear`,
  cooldown: 10,
  parameters: {"type":"music", "activeplayer": true, "previoussong": false},
  run: async (client, message, args, guildData, player, prefix) => {
    try {
      //clear the QUEUE
      player.queue.clear();
      //Send Success Message
      const iii = new MessageEmbed()
      .setDescription(`${emoji.msg.SUCCESS} | The queue is now cleared.`)
      .setColor(ee.color) 
      return message.channel.send({embeds: [iii]});
    } catch (e) {
      console.log(String(e.stack).bgRed)
			const emesdf = new MessageEmbed()
			.setColor(ee.wrongcolor)
			.setAuthor(`An Error Occurred`)
			.setDescription(`\`\`\`${e.message}\`\`\``);
			return message.channel.send({embeds: [emesdf]});
    }
  }
};
