const { MessageEmbed } = require("discord.js");
const Discord  = require("discord.js");
const config = require("../../botconfig/config.json");
const ee = require("../../botconfig/embed.json");
const emoji = require(`../../botconfig/emojis.json`);
const {
  getRandomInt
} = require("../../handlers/functions")
module.exports = {
    name: "bot-info",
    category: "Info",
    aliases: ["bot-info"],
    cooldown: 1,
    usage: "bot-info",
    description: "Shows music Stats, like amount of Commands and played Songs etc.",
    run: async (client, message, args, guildData, player, prefix) => {
        try {
            let totalSeconds = message.client.uptime / 1000;
            let days = Math.floor(totalSeconds / 86400);
            totalSeconds %= 86400;
            let hours = Math.floor(totalSeconds / 3600);
            totalSeconds %= 3600;
            let minutes = Math.floor(totalSeconds / 60);
            let seconds = Math.floor(totalSeconds % 60);
            
            let uptime = `${days} days, ${hours} hours, ${minutes} minutes and ${seconds} seconds`;
  
            let connectedchannelsamount = 0;
            let guilds = client.guilds.cache.map((guild) => guild);
            for (let i = 0; i < guilds.length; i++) {
                if (guilds[i].me.voice.channel) connectedchannelsamount += 1;
            }
            if (connectedchannelsamount > client.guilds.cache.size) connectedchannelsamount = client.guilds.cache.size;

            const statsEmbed = new Discord.MessageEmbed()
            .setColor(ee.color)
            .setAuthor(client.user.tag, client.user.displayAvatarURL())
    .setTimestamp()
                 .setFooter(ee.footertext, ee.footericon)
                  .setDescription(`Hi, I'm Mozzie Music. My Work is to play Music. You can check every command by ${prefix}help. I am developed in JavaScript`)
               
                                    
                       
.addField("Owners", "[Danish#0330](https://discord.com/users/948760356803739658), [PEACE#0009](https://discord.com/users/751707449370869840), [!  𝐍𝐗𝐓丶YASH#0003](https://discord.com/users/902153852059525131) and Special thanks all supporters")
          
 .addFields (
                { name: `<:Settings:948911496262479923> **Servers**`, value: `\`\`\`Total: ${client.guilds.cache.size} servers\`\`\``, inline: true },
                { name: `<:mozzie:950443110473797652> **Server Id**`, value: `\`\`\`948804329056387133\`\`\``, inline: true },
                { name: `<:info:948903937279418371> **Node Version**`, value: `\`\`\`v${process.versions.node}\`\`\``, inline: true },
                { name: `<:djs:948913955852677210> **Discord.js**`, value: `\`\`\`v13.1.0\`\`\``, inline: true },
                { name: `<:uptime:948912427997724683> **Uptime**`, value: `\`\`\`${uptime}\`\`\``, inline: true },

                { name: `<:vc:948912691047727104> **Music**`, value: `\`\`\`Playing Music In ${connectedchannelsamount} Servers\`\`\``, inline: true }
                )
            message.channel.send({embeds: [statsEmbed]});
        } catch (e) {
            console.log(String(e.stack).bgRed)
			const emesdf = new MessageEmbed()
			.setColor(ee.wrongcolor)
			.setAuthor(`An Error Occurred`)
			.setDescription(`\`\`\`${e.message}\`\`\``);
			return message.channel.send({embeds: [emesdf]});
        }
    }
}
