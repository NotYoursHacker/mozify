const { MessageEmbed, MessageButton, MessageActionRow
} = require("discord.js");
const config = require("../../botconfig/config.json");
const ee = require("../../botconfig/embed.json");
const emoji = require('../../botconfig/emojis.json');
module.exports = {
  name: "invite",
  category: "info",
  aliases: ["invite", "inv", "i"],
  cooldown: 5,
  usage: "invite",
  description: "Gives you an Invite link for this Bot",
  run: async (client, message, args, guildData, player, prefix) => {
    try {
   const mainmenu = new MessageEmbed()
.setTitle("Invite Links For Mozzie!") 
 .addField('Mozzie', `[Invite Me](https://discord.com/api/oauth2/authorize?client_id=948803590951153695&permissions=8&scope=bot)`, true) 
.addField('Vote Me', `[Click here](https://top.gg/bot/948803590951153695/vote)`, true) 
.addField('Support Server', `[Click here](https://discord.gg/yE5Azypyhe)`)
.setColor(message.guild.me.displayHexColor !== '#000000' ? message.guild.me.displayHexColor : "#ff0000") 
      message.channel.send({embeds: [mainmenu]});
    } catch (e) {
      console.log(String(e.stack).bgRed)
const emesdf = new MessageEmbed()
.setColor(message.guild.me.displayHexColor !== '#000000' ? message.guild.me.displayHexColor : "#ff0000") 
.setAuthor(`An error occurred`)
.setDescription(`\`\`${e.message}\`\`\``);
return message.channel.send({embeds: [emesdf]});
    }
  }
} 
