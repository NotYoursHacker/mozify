const { MessageEmbed, MessageButton, MessageActionRow
} = require("discord.js");
const config = require("../../botconfig/config.json");
const ee = require("../../botconfig/embed.json");
const emoji = require('../../botconfig/emojis.json');
module.exports = {
  name: "help",
  category: "info",
  aliases: ["help", "commands", "h"],
  cooldown: 5,
  usage: "help",
  description: "Gives you an Invite link for this Bot",
  run: async (client, message, args, guildData, player, prefix) => {
    try {
   const mainmenu = new MessageEmbed()
.setAuthor(`Mozzie Help Panel`, client.user.displayAvatarURL({dynamic: true}), config.links.opmusicinv)
 .addField(`General [5]`, `\`247\`, \`autoplay\`, \`prefix\`, \`reset\`, \`requester\``) 
 .addField(`Music [20]`, `\`clear\`, \`join\`, \`disconnect\`, \`loop\`, \`nowplaying\`, \`replay\`, \`pause\`, \`play\`, \`queue\`, \`remove\`, \`seek\`, \`grab\`, \`resume\`, \`search\`, \`previous\`, \`shuffle\`, \`skip\`, \`skipto\`, \`stop\`, \`volume\``) 
 .addField(`Filters [8]`, `\`8d\`, \`darthvader\`, \`karaoke\`, \`nightcore\`, \`pitch\`, \`slowmotion\`, \`speed\`, \`tremolo\``)
.addField(`Utilities [6]`, `\`help\`, \`invite\`, \`ping\`, \`bot-info\`, \`vote\`, \`support\``)
.setTimestamp() 
  .setFooter(ee.footertext, ee.footericon)
.setColor(message.guild.me.displayHexColor !== '#000000' ? message.guild.me.displayHexColor : "#ff0000") 

      message.channel.send({embeds: [mainmenu]});
    } catch (e) {
      console.log(String(e.stack).bgRed)
const emesdf = new MessageEmbed()
.setColor(message.guild.me.displayHexColor !== '#000000' ? message.guild.me.displayHexColor : "#ff0000") 
.setAuthor(`An error occurred`)
.setDescription(`\`\`${e.message}\`\`\``);
return message.channel.send({embeds: [emesdf]});
    }
  }
} 
